def do_sort(array, reverse=False):
    list.sort(array, reverse=reverse)